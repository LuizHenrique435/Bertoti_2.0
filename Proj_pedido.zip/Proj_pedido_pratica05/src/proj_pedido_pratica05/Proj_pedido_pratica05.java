/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proj_pedido_pratica05;

/**
 *
 * @author Manhã
 */
public class Proj_pedido_pratica05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Data dataPedido = new Data(13, 9, 2023);
        Cliente cliente = new Cliente("João", 123456789, new Data(13, 9, 2023));
        Pedido pedido = new Pedido(1001, cliente, dataPedido);

        Item item1 = new Item(1, 3, 10.5);
        Item item2 = new Item(2, 2, 8.0);

        pedido.adicionarItem(item1);
        pedido.adicionarItem(item2);

        pedido.imprimir();
        pedido.calcularTotal();
    }
    
}
