/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proj_pedido_pratica05;

import java.util.ArrayList;

/**
 *
 * @author Manhã
 */
public class Pedido {
    
       private int numero;
    private Cliente cliente;
    private Data data;
    private ArrayList<Item> lista;

    public Pedido(int numero, Cliente cliente, Data data) {
        this.numero = numero;
        this.cliente = cliente;
        this.data = data;
        this.lista = new ArrayList<>();
    }

    public void adicionarItem(Item item) {
        lista.add(item);
    }

    public void removerItem(Item item) {
        lista.remove(item);
    }

    public void calcularTotal() {
        double total = 0;
        for (Item item : lista) {
            total += item.calcularCustoItem();
        }
        System.out.println("Total do pedido: " + total);
    }

    public void imprimir() {
        System.out.println("Número do Pedido: " + numero);
        System.out.println("Cliente:");
        cliente.imprimir();
        System.out.println("Data do Pedido: " + data.formatarData());
        System.out.println("Itens:");
        for (Item item : lista) {
            item.imprimir();
        }
    }
    
}
